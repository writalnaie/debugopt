#!/usr/bin/env python

import gdb
import re
import itertools
import sys
import os
import os.path
import platform
import traceback
import datetime

def dprint(fmt, *args):
    return
    if len(args) != 0:
        gdb.write('=====> ' + fmt % args)
    else:
        gdb.write('=====> ' + str(fmt) + '\n')

class DebugoptUtility(object):
    """ Utility function and variables that are not expected to be exported to debugopt.gdb """

    machine_amd64 = 'x86_64'
    machine_mips3 = 'mips64'
    machine_armv7 = 'armv7l'
    keyword_amd64 = 'amd64'
    keyword_mips3 = 'mips3'
    keyword_armv7 = 'armv7'

    suffix_map = {
        machine_amd64: keyword_amd64,
        machine_mips3: keyword_mips3,
        machine_armv7: keyword_armv7,
    }

    unittest = False
    class Caller(object):
        def __init__(self, caller):
            self.caller = caller
        def __call__(self, *args, **kws):
            try:
                self.caller(*args, **kws)
            except Exception as exc:
                ex_str = traceback.format_exc()
                gdb.write('%s' % ex_str)
                if DebugoptUtility.unittest:
                    gdb.execute('quit')

    ###################################################################################################
    #   Commands for retrieving gdb information
    ###################################################################################################
    @staticmethod
    def gdb_check_print_demangle():
        """ Return True if print demangle """
        print_demangle_desc = gdb.execute('show print demangle', to_string = True)
        if print_demangle_desc.split()[-1][:-1] == 'on':
            return True
        else:
            return False

    @staticmethod
    def gdb_check_scheduler_locking():
        """ Return True if the scheduler locking is on """
        try:
            scheduler_locking = gdb.execute('show scheduler-locking', from_tty = True, to_string = True)
        except Exception as ex:
            return False
        if scheduler_locking.split()[-1][1:-2] == 'on':
            return True
        else:
            return False

    @staticmethod
    def gdb_info_breakpoints():
        """ Return a list of tuple (addr, what) where addr is the address(in string) and what is the what explanation"""
        breakpoint_desc = gdb.execute('info breakpoints', to_string = True)
        breakpoint_list = re.findall(r'(^\d+) |[ \t](0x[0-9a-zA-Z]+) (.*)', breakpoint_desc, re.MULTILINE)
        breakpoint_map_map = {}
        if breakpoint_desc.startswith('Num'):
            breakpoint_last = ''
            for breakpoint in breakpoint_list:
                if breakpoint[0] != '':
                    breakpoint_last = breakpoint[0]
                    breakpoint_map_map[breakpoint_last] = {}
                else:
                    breakpoint_map_map[breakpoint_last][breakpoint[1]] = breakpoint[2]
        return breakpoint_map_map

    @staticmethod
    def gdb_check_started():
        return gdb.selected_inferior().pid != 0

    @staticmethod
    def gdb_get_backtrace():
        backtrace_desc = gdb.execute('backtrace', to_string = True)
        backtrace_line_list = backtrace_desc.split('\n')
        line_curr = re.search(r'at +([^ ]+)$', backtrace_line_list[0])
        if line_curr:
            return line_curr.group(1)

    @staticmethod
    def gdb_get_symbol(address):
        # Record the status of print demangle
        print_demangle = DebugoptUtility.gdb_check_print_demangle()
        gdb.execute('set print demangle off')

        symbol_desc = gdb.execute('info symbol %s' % address, to_string = True)
        symbol_desc_split = symbol_desc.split()
        symbol = symbol_desc_split[0]
        offset = int(symbol_desc_split[2]) if symbol_desc_split[1] == '+' else 0

        # Recover the status of print demangle
        if print_demangle:
            gdb.execute('set print demangle on')

        return (symbol, offset)

    @staticmethod
    def gdb_get_address(symbol):
        try:
            address_desc = gdb.execute('info address %s' % symbol, to_string = True)
            address = re.search(r'[^0-9a-zA-Z]0x[0-9a-zA-Z]+[^0-9a-zA-Z]', address_desc).group(0)[1:-1]
            return address
        except:
            return None

    @staticmethod
    def gdb_get_target_list():
        """Find all sections in the form [(base, limit, source)]"""
        target_list_desc = gdb.execute('info target', to_string = True).split('\n')
        target_list = []
        for target_desc in target_list_desc:
            target_desc = target_desc.split()
            if len(target_desc) == 7 and target_desc[1] == '-':
                target_base, target_limit, target_section, target_source = int(target_desc[0], 16), int(target_desc[2], 16), target_desc[4], target_desc[6]
                target_list.append((target_base, target_limit, target_section, target_source))
            elif len(target_desc) == 5 and target_desc[1] == '-':
                target_base, target_limit, target_section = int(target_desc[0], 16), int(target_desc[2], 16), target_desc[4]
                target_list.append((target_base, target_limit, target_section, None))
        return target_list

    @staticmethod
    def gdb_get_target(target_list, address):
        target = next(itertools.dropwhile(lambda target: not (target[0] <= int(address, 16) and int(address, 16) <= target[1]), target_list), (None, None, None))
        return target[2]        

    @staticmethod
    def gdb_uint(value):
        value_desc = str(value)
        dprint('integer = %s\n', value_desc)
        if ' ' in value_desc:
            return int(value_desc.split()[0], 16)
        else:
            r = int(value)
            if r >= 0:
                return r
            else:
                return r + 0x800000000000

    ###################################################################################################
    #   Utility functions
    ###################################################################################################

    scheduler_locking = None

    @staticmethod
    def scheduler_pre():
        # Record the status of scheduler
        DebugoptUtility.scheduler_locking = DebugoptUtility.gdb_check_scheduler_locking()
        gdb.execute('set scheduler-locking on')

    @staticmethod
    def scheduler_post():
        # Recover the status of scheduler
        if not DebugoptUtility.scheduler_locking:
            gdb.execute('set scheduler-locking off')

    @staticmethod
    def get_target_path(target):
        if target != None:
            return '"%s"' % target
        else:
            return '(void *)0'

    @staticmethod
    def call_function(func, *args):
        command = 'call %s(%s)' % (func, ', '.join(args))
        dprint('%s ...\n', command);

        DebugoptUtility.scheduler_pre()
        gdb.execute(command)
        DebugoptUtility.scheduler_post()
        dprint('%s !!!\n', command);

    @staticmethod
    def eval_function(func, *args):
        command = '%s(%s)' % (func, ', '.join(args))
        dprint('eval %s ...\n', command);

        DebugoptUtility.scheduler_pre()
        ret = gdb.parse_and_eval(command)
        dprint('eval %s = %s\n', command, ret);
        DebugoptUtility.scheduler_post()
        return ret

    @staticmethod
    def exec_command(cmd):
        DebugoptUtility.scheduler_pre()
        output = gdb.execute(cmd, to_string = True)
        DebugoptUtility.scheduler_post()
        return output        

    @staticmethod
    def call_break_node(symbol, target):
        target_path = DebugoptUtility.get_target_path(target)
        ret = DebugoptUtility.eval_function('__debugopt_break_node', symbol, target_path)
        ret_pointer = DebugoptUtility.gdb_uint(gdb.parse_and_eval('*(void **)&__debugopt_return_pointer'))
        return ret_pointer

    @staticmethod
    def call_get_metadata(symbol, target):
        target_path = DebugoptUtility.get_target_path(target)
        ret = DebugoptUtility.eval_function('__debugopt_get_metadata', symbol, target_path)
        ret_pointer = DebugoptUtility.gdb_uint(gdb.parse_and_eval('*(void **)&__debugopt_return_pointer'))
        return ret_pointer

    jump_counter = {}

    @staticmethod
    def call_jump(symbol):
        if symbol not in DebugoptUtility.jump_counter:
            DebugoptUtility.jump_counter[symbol] = 1

            target = gdb.solib_name(int(symbol, 16))
            target_path = DebugoptUtility.get_target_path(target)
            DebugoptUtility.call_function('__debugopt_jump', symbol, target_path)
        else:
            DebugoptUtility.jump_counter[symbol] += 1

    @staticmethod
    def call_jump_recovery(symbol):
        DebugoptUtility.jump_counter[symbol] -= 1
        if DebugoptUtility.jump_counter[symbol] == 0:
            del DebugoptUtility.jump_counter[symbol]

            target = gdb.solib_name(int(symbol, 16))
            target_path = DebugoptUtility.get_target_path(target)
            DebugoptUtility.call_function('__debugopt_jump_recovery', symbol, target_path)

    @staticmethod
    def call_jump_src(symbol):
        target = gdb.solib_name(int(symbol, 16))
        metadata = DebugoptUtility.call_get_metadata(symbol, target)
        src_addr = DebugoptUtility.gdb_uint(gdb.parse_and_eval('*(void **)(0x%x + sizeof(void *) * 3)' % metadata))
        src_addr_size = DebugoptUtility.gdb_uint(DebugoptUtility.eval_function('__debugopt_get_trampoline_size'))
        thread_desc = gdb.execute('info threads', to_string = True)
        thread_info_list = re.findall(r'^([*]?)\s+(\d+)\s|\s(0x[0-9a-f]+)\sin', thread_desc, re.MULTILINE)
        thread_info_dict = {}

        thread_curr_id = 0
        thread_curr_curr = False
        for curr, tid, addr in thread_info_list:
            if tid != '':
                thread_curr_id = int(tid)
                thread_curr_curr = True if curr == '*' else False
                # If the format is not matched, we can ensure that $pc must be the start address of some symbol -- hence, it is not necessary to step instructions
                thread_info_dict[thread_curr_id] = (thread_curr_curr, 0)
            else:
                thread_info_dict[thread_curr_id] = (thread_curr_curr, int(addr, 16))
        for tid in thread_info_dict:
            if src_addr < thread_info_dict[tid][1] and thread_info_dict[tid][1] < src_addr + src_addr_size:
                gdb.execute('thread %d' % tid, to_string = True)
                pc = DebugoptUtility.gdb_uint(gdb.parse_and_eval('$pc'))
                dprint('0x%x - 0x%x - 0x%x\n', pc, src_addr, src_addr + src_addr_size)
                while src_addr < pc and pc < src_addr + src_addr_size:
                    DebugoptUtility.exec_command('si')
                    pc = DebugoptUtility.gdb_uint(gdb.parse_and_eval('$pc'))
        thread_curr_curr_id = [tid for tid in thread_info_dict if thread_info_dict[tid][0]][0]
        gdb.execute('thread %d' % thread_curr_curr_id, to_string = True)

    @staticmethod
    def breakpoints_diff(curr_set, self_map, other_map):
        """From breakpoints index set to get different breakpoints"""
        self_set = { breakpoints for curr in curr_set for breakpoints in self_map.get(curr, {}) }
        other_set = { breakpoints for curr in curr_set for breakpoints in other_map.get(curr, {}) }
        return self_set - other_set

    @staticmethod
    def breakpoints_symbol_list(curr_set):
        """Getting debuging symbol from breakpoints address set"""
        symbol_list = []
        for curr in curr_set:
            symbol = DebugoptUtility.gdb_get_symbol(curr)[0]
            if symbol.endswith('$do'):
                symbol_dbg_address = DebugoptUtility.gdb_get_address(symbol)
                symbol_list.append(symbol_dbg_address)
        return symbol_list

    @staticmethod
    def breakpoints_redirect_symbol_list(symbol_list):
        redirect_symbol_list = []
        for symbol in symbol_list:
            target = gdb.solib_name(int(symbol, 16))
            node = DebugoptUtility.gdb_uint(DebugoptUtility.call_break_node(symbol, target))
            node_size = DebugoptUtility.gdb_uint(gdb.parse_and_eval('*(long *)0x%x' % node))
            for index in range(node_size):
                node_src = DebugoptUtility.gdb_uint(gdb.parse_and_eval('*(void **)(0x%x + sizeof(void *) * %d)' % (node, index + 1)))
                redirect_symbol_list.append('0x%x' % node_src)
        return redirect_symbol_list


    notify = ''
    @staticmethod
    def init_notify_path(path):
        DebugoptUtility.notify = '%s/bin/notify.so' % (os.path.dirname(path))

    ###################################################################################################
    #   Commands for registering the dbg library
    ###################################################################################################

    @staticmethod
    def handle_new_objfile(event):
        new_objfile = event.new_objfile.filename
        DebugoptUtility.solib_list.append(new_objfile)
        dprint('!!!: %s\n', new_objfile)
        if new_objfile.endswith('.dbg.so') or new_objfile.endswith('notify.so'):
            dprint('LD: %s\n', new_objfile)
        if new_objfile == DebugoptUtility.notify:
            DebugoptUtility.handle_break_post(update_by_insert = False)
        else:
            DebugoptUtility.handle_break_pre()

    inferior_started = False
    inferior_attached = False
    solib_list = []

    @staticmethod
    def handle_run_pre():
        DebugoptUtility.solib_list = []
        DebugoptUtility.jump_counter = {}
        DebugoptUtility.inferior_started = True
        DebugoptUtility.inferior_attached = False

    @staticmethod
    def handle_exited(event):
        DebugoptUtility.inferior_started = False
        DebugoptUtility.inferior_attached = False

    ###################################################################################################
    #   Methods for handling breakpoint
    ###################################################################################################

    breakpoints_pre_map                         = {}
    breakpoints_post_map                        = {}
    breakpoints_debugopt_set                    = set()
    breakpoints_debugopt_pending_set            = set()

    @staticmethod
    def handle_break_pre():
        DebugoptUtility.breakpoints_pre_map = DebugoptUtility.gdb_info_breakpoints()

    @staticmethod
    def handle_break_post(update_by_insert):
        DebugoptUtility.breakpoints_post_map = DebugoptUtility.gdb_info_breakpoints()
        if update_by_insert:
            if len(DebugoptUtility.breakpoints_post_map) != len(DebugoptUtility.breakpoints_pre_map):
                DebugoptUtility.breakpoints_debugopt_set |= set(DebugoptUtility.breakpoints_post_map.keys()) - set(DebugoptUtility.breakpoints_pre_map.keys())

        dprint('Current pre: %s\n', DebugoptUtility.breakpoints_pre_map)
        dprint('Current post: %s\n', DebugoptUtility.breakpoints_post_map)
        breakpoints_curr_set = DebugoptUtility.breakpoints_diff(DebugoptUtility.breakpoints_debugopt_set, DebugoptUtility.breakpoints_post_map, DebugoptUtility.breakpoints_pre_map)
        dprint('Current diff: %s\n', breakpoints_curr_set)
        if len(breakpoints_curr_set) == 0 and len(DebugoptUtility.breakpoints_debugopt_pending_set) == 0:
            return

        if DebugoptUtility.inferior_started or DebugoptUtility.inferior_attached:
            breakpoints_curr_set |= DebugoptUtility.breakpoints_debugopt_pending_set
            DebugoptUtility.breakpoints_debugopt_pending_set = set()
            dprint('Current set: %s\n', breakpoints_curr_set)
            breakpoints_symbol_list = DebugoptUtility.breakpoints_symbol_list(breakpoints_curr_set)
            dprint('Current symbol: %s\n', breakpoints_symbol_list)
            breakpoints_redirect_symbol_list = DebugoptUtility.breakpoints_redirect_symbol_list(breakpoints_symbol_list)
            dprint('Current redirect symbol: %s\n', breakpoints_redirect_symbol_list)
            for breakpoints_redirect_symbol in breakpoints_redirect_symbol_list:
                DebugoptUtility.call_jump_src(breakpoints_redirect_symbol)
                DebugoptUtility.call_jump(breakpoints_redirect_symbol)
        else:
            DebugoptUtility.breakpoints_debugopt_pending_set |= set(breakpoints_curr_set)


    @staticmethod
    def handle_break(command, *args):
        DebugoptUtility.handle_break_pre()
        breakpoint_desc = gdb.execute(' '.join((command,) + args), to_string = True)
        DebugoptUtility.handle_break_post(update_by_insert = True)

    @staticmethod
    def handle_delete(*args):
        for arg in args:
            if arg in DebugoptUtility.breakpoints_debugopt_set:
                breakpoints_pre_map = DebugoptUtility.gdb_info_breakpoints()
                gdb.execute('delete %s' % arg, to_string = True)
                breakpoints_post_map = DebugoptUtility.gdb_info_breakpoints()

                breakpoints_curr_set = DebugoptUtility.breakpoints_diff(DebugoptUtility.breakpoints_debugopt_set, breakpoints_pre_map, breakpoints_post_map)
                if len(breakpoints_curr_set) == 0:
                    continue

                breakpoints_symbol_list = DebugoptUtility.breakpoints_symbol_list(breakpoints_curr_set)
                breakpoints_redirect_symbol_list = DebugoptUtility.breakpoints_redirect_symbol_list(breakpoints_symbol_list)
                for breakpoints_redirect_symbol in breakpoints_redirect_symbol_list:
                    DebugoptUtility.call_jump_recovery(breakpoints_redirect_symbol)
            else:
                gdb.write('Invalid debugopt breakpoint %s!\n' % arg)

    @staticmethod
    def handle_enable(*args):
        for arg in args:
            if arg in DebugoptUtility.breakpoints_debugopt_set:
                gdb.execute('enable %s' % arg, to_string = True)
            else:
                gdb.write('Invalid debugopt breakpoint %s!\n' % arg)

    @staticmethod
    def handle_disable(*args):
        for arg in args:
            if arg in DebugoptUtility.breakpoints_debugopt_set:
                gdb.execute('disable %s' % arg, to_string = True)
            else:
                gdb.write('Invalid debugopt breakpoint %s!\n' % arg)

    @staticmethod
    def do_step_instruction(to_string):
        message = gdb.execute('stepi', to_string = True)

        pc_symbol = DebugoptUtility.gdb_get_symbol('$pc')
        if pc_symbol[1] == 0:
            pc_symbol_dbg = DebugoptUtility.gdb_get_address(pc_symbol[0] + '$do')
            if pc_symbol_dbg:
                DebugoptUtility.call_jump(pc_symbol_dbg)
                message = gdb.execute('stepi', to_string = True)
                DebugoptUtility.call_jump_recovery(pc_symbol_dbg)
            if not to_string:
                gdb.write(message)
            else:
                return message
        else:
            if not to_string:
                gdb.write(message)
            else:
                return message

    @staticmethod
    def do_step(to_string):
        line_curr = DebugoptUtility.gdb_get_backtrace()
        if line_curr:
            while True:
                message = DebugoptUtility.do_step_instruction(True)
                line_next = DebugoptUtility.gdb_get_backtrace()
                if not line_next:
                    gdb.execute('finish', to_string = True)
                elif line_curr != line_next:
                    break
            if not to_string:
                message_si = re.match(r'^0x[0-9a-f]+[ \t]+(.*)', message)
                if message_si:
                    gdb.write(message_si.group(1) + '\n')
                else:
                    gdb.write(message)
        else:
            gdb.execute('step', to_string = to_string)

    @staticmethod
    def handle_step(*args):
        repeat = 1 if len(args) == 0 else int(args[0])
        for index in range(repeat - 1):
            DebugoptUtility.do_step(True)
        DebugoptUtility.do_step(False)

    @staticmethod
    def handle_next(*args):
        repeat = 1 if len(args) == 0 else int(args[0])
        gdb.execute('next %s' % repeat)

    @staticmethod
    def handle_step_instruction(*args):
        repeat = 1 if len(args) == 0 else int(args[0])
        for index in range(repeat - 1):
            DebugoptUtility.do_step_instruction(True)
        DebugoptUtility.do_step_instruction(False)

    @staticmethod
    def handle_next_instruction(*args):
        repeat = 1 if len(args) == 0 else int(args[0])
        gdb.execute('nexti %s' % repeat)

    @staticmethod
    def handle_attach():
        DebugoptUtility.inferior_attached = True
        DebugoptUtility.call_function('__debugopt_setenv', '"DEBUGOPT"', '"%s"' % DebugoptUtility.notify, '1')
        target_list = DebugoptUtility.gdb_get_target_list()
        for target_base, target_limit, target_section, target_source in target_list:
            if target_section == '.debugopt.load.init':
                dprint('%s\n', (target_base, target_limit, target_section, target_source))
                gdb.execute('call ((void (*)())(0x%x))()' % target_base)

    @staticmethod
    def handle_detach():
        jump = next(iter(DebugoptUtility.jump_counter), None)
        while jump != None:
            DebugoptUtility.call_jump_recovery(jump)
            jump = next(iter(DebugoptUtility.jump_counter), None)
        target_list = DebugoptUtility.gdb_get_target_list()

        target_counter = {}
        for target_base, target_limit, target_section, target_source in target_list:
            if target_section == '.debugopt.counter':
                if target_source not in target_counter:
                    target_counter[target_source] = (target_base, target_limit, target_section, target_source)

        for target_source in target_counter:
            # c: counter; p: path; u: unload
            target_base, target_limit, target_section, target_source = target_counter[target_source]
            if type(target_source) == str and target_source.endswith('.dbg.so'):
                DebugoptUtility.call_function('__debugopt_strcpy', '((char *)0x%x)' % target_base, '"%s"' % target_source)
                DebugoptUtility.call_function('__debugopt_unload_handler', '0x%x' % target_base)

    @staticmethod
    def handle_init():
        gdb.write('=================================================== Debugopt =============================================\n')
        gdb.execute('set environment DEBUGOPT=%s' % DebugoptUtility.notify)
        gdb.events.new_objfile.connect(DebugoptUtility.Caller(DebugoptUtility.handle_new_objfile))
        gdb.events.exited.connect(DebugoptUtility.Caller(DebugoptUtility.handle_exited))

    @staticmethod
    def handle_init_fini():
        dprint('***** inferior_started=%s, pid=%s *****\n', DebugoptUtility.inferior_started, gdb.selected_inferior().pid)
        if not DebugoptUtility.inferior_started:
            if gdb.selected_inferior().pid != 0:
                DebugoptUtility.handle_attach()

    @staticmethod
    def handle_quit():
        if gdb.selected_inferior().pid != 0:
            DebugoptUtility.handle_detach()

    @staticmethod
    def handle_unittest():
        DebugoptUtility.unittest = True
    
###################################################################################################
#   Command for initializing debugopt
###################################################################################################
def __debugopt_init():
    DebugoptUtility.Caller(DebugoptUtility.handle_init)()
def __debugopt_init_fini():
    DebugoptUtility.Caller(DebugoptUtility.handle_init_fini)()
def __debugopt_unittest():
    DebugoptUtility.Caller(DebugoptUtility.handle_unittest)()

###################################################################################################
#   Command for hooking gdb commands
###################################################################################################
def __debugopt_hook_run():
    DebugoptUtility.Caller(DebugoptUtility.handle_run_pre)()

def __debugopt_hook_file():
    pass

def __debugopt_attach_post():
    DebugoptUtility.Caller(DebugoptUtility.handle_attach)()

def __debugopt_detach_pre():
    DebugoptUtility.Caller(DebugoptUtility.handle_detach)()

def __debugopt_quit_pre():
    DebugoptUtility.Caller(DebugoptUtility.handle_quit)()

###################################################################################################
#   Command for handling:
#           * debugopt-break
#           * debugopt-tbreak
#           * debugopt-hbreak
#           * debugopt-thbreak
#           * debugopt-rbreak
#           * debugopt-delete
###################################################################################################
def __debugopt_break(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_break)('break', *args)
def __debugopt_tbreak(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_break)('tbreak', *args)
def __debugopt_hbreak(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_break)('hbreak', *args)
def __debugopt_thbreak(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_break)('thbreak', *args)
def __debugopt_rbreak(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_break)('rbreak', *args)
def __debugopt_delete(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_delete)(*args)
def __debugopt_enable(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_enable)(*args)
def __debugopt_disable(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_disable)(*args)

###################################################################################################
#   Command for handling:
#           * debugopt-step
#           * debugopt-next
#           * debugopt-stepi
#           * debugopt-nexti
###################################################################################################
def __debugopt_step(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_step)(*args)
def __debugopt_next(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_next)(*args)
def __debugopt_step_instruction(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_step_instruction)(*args)
def __debugopt_next_instruction(*args):
    DebugoptUtility.Caller(DebugoptUtility.handle_next_instruction)(*args)

if __name__ == '__main__':
    DebugoptUtility.init_notify_path(__file__)
    gdb.execute('source %s.gdb' % __file__[:-3])

