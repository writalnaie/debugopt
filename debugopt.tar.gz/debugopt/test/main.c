int printf(const char *fmt, ...);

void foo(int n, int m) {
    int i;
    for (i = 1; i < m; i++) {
        int k = n * 3;
        int v = k * k;
        n = n + i;
        printf("%s %d\n", __PRETTY_FUNCTION__, v);
    }
}

void (*pfoo)(int, int) = foo;

int main() {
    pfoo(30, 5);
    return 0;
}

