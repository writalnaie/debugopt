#!/bin/bash

sudo ln -s `pwd`/debugopt-clang /usr/local/bin/debugopt-clang
sudo ln -s `pwd`/debugopt-clang++ /usr/local/bin/debugopt-clang++
sudo ln -s `pwd`/debugopt-gdb /usr/local/bin/debugopt-gdb
